# Unified Weighted Domination Framework — Reproducibility Repository

This repository contains the Jupyter notebook and companion workbook for reproducing the computational analyses for the manuscript **“A Unified Weighted Domination Framework for Epidemiological and Biological Networks.”**

## Contents

- `PPIN_Breast_cancer_and_Dog_vaccination_v5.ipynb` — analysis notebook (PPIN analysis and illustrative synthetic dog-vaccination example); regenerates the manuscript figures in a `paper/` folder.
- `PPIN_reproducibility_data.xlsx` — input workbook, including network metrics, interaction edges, and the driver-gene reference list.

## Run the notebook

1. Download/clone this repository.
2. Install Python 3.10+ and the packages listed in `requirements.txt`.
3. Open the notebook in Jupyter and run all cells from top to bottom.
4. Keep the Excel workbook in the same directory as the notebook. The notebook writes generated figures to `paper/`.

Example setup:

```bash
python -m pip install -r requirements.txt
jupyter notebook
```

## Notes

- The dog-vaccination example uses synthetic illustrative data, not municipal or field data.
- Results may vary in runtime depending on hardware and solver configuration.
- Please cite the associated manuscript when using this code or data.
